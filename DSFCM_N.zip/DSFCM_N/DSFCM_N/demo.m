% Written by Yuxuan Zhang 2018/3/26
% If you use this code, please cite the paper "Yuxuan Zhang, Xiangzhi Bai, Ruirui Fan, and Zihan Wang,
%" Deviation-Sparse Fuzzy C-Means with Neighbor Information Constraint"
% IEEE Transactions on Fuzzy Systems, 2018
%Date of Publication: 23 November 2018 
%DOI: 10.1109/TFUZZ.2018.2883033
% If you have any questions, feel free to contact me(zhangyuxuan1996@buaa.edu.cn)
% Also, feel free to make modifications on it
%% 
clear
clc

str1='..\source image\';
str2='..\result\';
%Parameters
C = 3;  %cluster numbers
error = 1e-6;
m=2;
for i=1:9
I = double(imread([str1,'1_',num2str(i),'.bmp']));
[Height,width] = size(I);
lambda = 1/4*std(I(:)); %This parameter 1/4 can be tuned
[E,center,U] = DSFCM_N(I,C,error,m,lambda);
[center,INDEX] = sort(center);
U = U(INDEX,:);
[~,lable]=max(U);
lable = reshape(lable,Height,width);
lable(lable==1)=0;
lable(lable==2)=85;
lable(lable==3)=170;
lable=uint8(lable);
% imshow(lable)
% imwrite(lable,[str2,'Result_1_',num2str(i),'.bmp'])
end
