% Written by Yuxuan Zhang 2018/3/26
% If you use this code, please cite the paper "Yuxuan Zhang, Xiangzhi Bai, Ruirui Fan, and Zihan Wang,
%" Deviation-Sparse Fuzzy C-Means with Neighbor Information Constraint"
% IEEE Transactions on Fuzzy Systems, 2018
%Date of Publication: 23 November 2018 
%DOI: 10.1109/TFUZZ.2018.2883033
% If you have any questions, feel free to contact me(zhangyuxuan1996@buaa.edu.cn)
% Also, feel free to make modifications on it
%% 
clear
clc

str1='..\source image\';
str2='..\result\';
%Parameters
C = 3;  %cluster numbers
error = 1e-6;
m=2;
for i=1:9
I = imread([str1,'2_',num2str(i),'.bmp']);
figure(1),
imshow(I)
II = double(I);
%(RGB->LAB)
% II= double(rgb2lab(I)); %for nature images
[height,width,~] = size(I);
II1 = II(:,:,1);
II2 = II(:,:,2);
II3 = II(:,:,3);
lambda = zeros(3,1);
lambda(1) = 1/4*std(II1(:));%this parameter 1/4 could be tuned
lambda(2) = 1/4*std(II2(:));%this parameter 1/4 could be tuned
lambda(3) = 1/4*std(II3(:));%this parameter 1/4 could be tuned
[E,center,U] = DSFCM_N(II,C,error,m,lambda);
rgb = zeros(C,3);
for j=1:C
rgb(j,:) = 255*lab2rgb(center(j,:));
end
[~,INDEX] = sort(center(1,:));
U = U(INDEX,:);
[~,lable]=max(U);
lable = reshape(lable,height,width);

result1 = zeros(height,width);
result2 = zeros(height,width);
result3 = zeros(height,width);

% for quantitive comparison
result1(lable==1)=0;
result2(lable==1)=100;
result3(lable==1)=255;

result1(lable==2)=170;
result2(lable==2)=100;
result3(lable==2)=170;

result1(lable==3)=255;
result2(lable==3)=100;
result3(lable==3)=0;


result  =zeros(height,width,3);
result(:,:,1) = result1;
result(:,:,2) = result2;
result(:,:,3) = result3;
figure(2),
result=uint8(result);
imshow(result)
imwrite(result,[str2,'2_',num2str(i),'.bmp'])
end
